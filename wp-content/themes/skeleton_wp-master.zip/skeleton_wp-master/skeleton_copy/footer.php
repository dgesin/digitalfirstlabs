<?php st_before_footer();?>

<?php wp_footer();?>

<?php st_after_footer();?>

</body>
</html>
