<?php

/**
 * Oh bother!
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'Oh bother! No forums were found here!', 'bbpress' ); ?></p>
</div>
